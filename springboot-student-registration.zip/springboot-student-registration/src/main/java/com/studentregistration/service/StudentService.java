package com.studentregistration.service;

import java.util.List;
import com.studentregistration.exception.ResourceNotFoundException;
import com.studentregistration.model.Student;

public interface StudentService 
{
	Student updateStudent(Student input, Student student);
	
	List<Student> getAllStudents();
	
	List<Student> getAllStudentsGreaterThanNightyPercentage();
	
	Student getStudentById(Long empId) throws ResourceNotFoundException;
	
	Student getStudentByFirstAndLastName(String firstName,String lastName) throws ResourceNotFoundException;
	
	void deleteStudent(Student empl);
	
	Student save(Student student);
}
