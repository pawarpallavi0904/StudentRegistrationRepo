package com.studentregistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//The entry point of the Spring Boot Application. Combination of @Configuration, @EnableAutoConfiguration and @ComponentScan annotations
public class Application
{
	public static void main(String[] args)
	{
		SpringApplication.run(Application.class, args);
	}
}
