package com.studentregistration.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.studentregistration.exception.ResourceNotFoundException;
import com.studentregistration.model.Student;
import com.studentregistration.service.StudentService;
import jakarta.validation.Valid;

//Controller Class : Responsible for processing incoming requests and returning response
@RestController
public class StudentController 
{	
	@Autowired 																//used for automatic dependency injection
	private StudentService studentService;
		
	@GetMapping("/studentRegistration/students") 							//Retrieve the all the data
	public List<Student> getAllstudents() 
	{
		return studentService.getAllStudents();
	}
	
	@GetMapping("/studentRegistration/students/aboveNightyMarks") 			//Retrieve the data whose percentage > 90
	public List<Student> getAllStudentsGreaterThanNightyPercentage() 
	{
		return studentService.getAllStudentsGreaterThanNightyPercentage();
	}

	@GetMapping("/studentRegistration/students/{id}") 						//Retrive the data of particular id
	public ResponseEntity<Student> getStudentById(@PathVariable(value = "id") Long studentId) throws ResourceNotFoundException
	{
		Student student = studentService.getStudentById(studentId);
		return ResponseEntity.ok().body(student);
	}
	
	@GetMapping("/studentRegistration/students/name") 						//Retrive the data by using first and last name
	public ResponseEntity<Student> getStudentByFirstAndLastName(@RequestParam(value = "firstName") String firstName, 
			@RequestParam(value = "lastName") String lastName) throws ResourceNotFoundException
	{
		Student student = studentService.getStudentByFirstAndLastName(firstName, lastName);
		return ResponseEntity.ok().body(student);
	}

	@PostMapping("/studentRegistration/saveStudent") 						//save the data
	public Student createStudent(@RequestPart Student student,
			@RequestParam("image") MultipartFile image) throws IOException
	{
		byte[] data = image.getBytes(); 
		student.setImageData(data);
		return studentService.save(student);
	}

	@PutMapping("/studentRegistration/students/{id}") 						//Update the data
	public ResponseEntity<Student> updateStudent(@PathVariable(value = "id") Long studentId,
			@Valid @RequestBody Student studentDetails) throws ResourceNotFoundException
	{
		Student student = studentService.getStudentById(studentId);
		final Student updatedStudent = studentService.updateStudent(studentDetails, student);
		return ResponseEntity.ok(updatedStudent);
	}

	@DeleteMapping("/studentRegistration/students/{id}") 					//delete the data of particular id
	public Map<String, Boolean> deleteStudent(@PathVariable(value = "id") Long studentId) throws ResourceNotFoundException
	{
		Student student = studentService.getStudentById(studentId);
		studentService.deleteStudent(student);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
