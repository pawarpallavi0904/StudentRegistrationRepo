package com.studentregistration.model;

import java.io.Serializable;
import java.util.Arrays;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "student")
public class Student implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "first_name", nullable = false)
	private String firstName;
	
	@Column(name = "last_name" , nullable = false)
	private String lastName;
	
	@Column(name = "mother_name")
	private String motherName;
		
	@Column(name = "father_name")
	private String fatherName;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "email_address", nullable = false)
	@Email
	private String emailId;
	
	@Column(name = "image", nullable = false, length = 100000)
	private byte[] imageData;
	
	@Column(name = "percentage")
	private double percentage;
	
	public Student() 
	{
		
	}
	
	public Student(String firstName, @NotBlank String lastName, String motherName, String fatherName,
			String address, String emailId, byte[] imageData, double percentage) 
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.motherName = motherName;
		this.fatherName = fatherName;
		this.address = address;
		this.emailId = emailId;
		this.imageData = imageData;
		this.percentage = percentage;
	}
	
	public long getId() 
	{
		return id;
	}
	
	public void setId(long id) 
	{
		this.id = id;
	}
	
	public String getFirstName() 
	{
		return firstName;
	}
	public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	
	public String getEmailId()
	{
		return emailId;
	}
	public void setEmailId(String emailId)
	{
		this.emailId = emailId;
	}
	
	public byte[] getImageData() 
	{
		return imageData;
	}

	public void setImageData(byte[] imageData)
	{
		this.imageData = imageData;
	}

	public String getMotherName()
	{
		return motherName;
	}

	public void setMotherName(String motherName) 
	{
		this.motherName = motherName;
	}

	public String getFatherName()
	{
		return fatherName;
	}

	public void setFatherName(String fatherName)
	{
		this.fatherName = fatherName;
	}

	public String getAddress()
	{
		return address;
	}

	public void setAddress(String address) 
	{
		this.address = address;
	}

	public double getPercentage()
	{
		return percentage;
	}

	public void setPercentage(double percentage) 
	{
		this.percentage = percentage;
	}

	@Override
	public String toString() 
	{
		return "Student [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", motherName="
				+ motherName + ", fatherName=" + fatherName + ", address=" + address + ", emailId=" + emailId
				+ ", imageData=" + Arrays.toString(imageData) + ", percentage=" + percentage + "]";
	}
}
