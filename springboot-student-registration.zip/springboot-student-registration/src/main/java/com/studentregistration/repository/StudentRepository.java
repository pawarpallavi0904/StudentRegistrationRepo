package com.studentregistration.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.studentregistration.model.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long>
{
	@Query("SELECT s FROM Student s WHERE lower(s.firstName) like lower(concat('%', :firstName,'%')) and lower(s.lastName) like lower(concat('%', :lastName,'%'))")
	Student findStudentByFirstAndLastName(String firstName, String lastName);
}
