package com.studentregistration.serviceimpl;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.studentregistration.exception.ResourceNotFoundException;
import com.studentregistration.model.Student;
import com.studentregistration.repository.StudentRepository;
import com.studentregistration.service.StudentService;
import io.micrometer.common.util.StringUtils;


//Service Class : Business Logic
@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public Student updateStudent(Student input, Student student) {
		if(!StringUtils.isBlank(input.getFirstName()))
		{
			student.setFirstName(input.getFirstName());
		}
		if(!StringUtils.isBlank(input.getLastName()))
		{
			student.setLastName(input.getLastName());
		}
		if(!StringUtils.isBlank(input.getFatherName()))
		{
			student.setFatherName(input.getFatherName());
		}
		if(!StringUtils.isBlank(input.getMotherName()))
		{
			student.setMotherName(input.getMotherName());
		}
		if(!StringUtils.isBlank(input.getAddress()))
		{
			student.setAddress(input.getAddress());
		}
		if(!StringUtils.isBlank(input.getEmailId()))
		{
			student.setEmailId(input.getEmailId());
		}
		if(input.getPercentage() > 0)
		{
			student.setPercentage(input.getPercentage());
		}
		return studentRepository.save(student);
	}
	
	@Override
	public Student save(Student student) 
	{
		return studentRepository.save(student);
	}

	@Override
	public List<Student> getAllStudents() 
	{
		return studentRepository.findAll();
	}

	@Override
	public List<Student> getAllStudentsGreaterThanNightyPercentage() 
	{
		List<Student> studentList = studentRepository.findAll();
		//using java 8
		return Optional.ofNullable(studentList)
	            .orElseGet(Collections::emptyList).stream().filter(s -> s.getPercentage() > 90).collect(Collectors.toList());
	}
	
	@Override
	public Student getStudentById(Long studentId) throws ResourceNotFoundException 
	{
		Optional<Student> studentResponse = studentRepository.findById(studentId);
		Student student=null;
		if(studentResponse.isPresent()) 
		{
			student=studentResponse.get();
		}
		else 
		{
			throw new ResourceNotFoundException("Student not found for this id :: " + studentId);
		}
		return student;
	}

	@Override
	public Student getStudentByFirstAndLastName(String firstName, String lastName) throws ResourceNotFoundException 
	{
		Student student = studentRepository.findStudentByFirstAndLastName(firstName, lastName);
		if(student == null){
			throw new ResourceNotFoundException("Student not found for this first name :: " + firstName + " and last name :: " + lastName);
		}
		return student;
	}
	
	@Override
	public void deleteStudent(Student student) 
	{
		studentRepository.delete(student);
	}
}
