package com.studentregistration.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.studentregistration.exception.ResourceNotFoundException;
import com.studentregistration.model.Student;
import com.studentregistration.repository.StudentRepository;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class StudentServiceImplTest{
	
	@InjectMocks
	StudentServiceImpl studentServiceImpl;
	
	@Mock
	private StudentRepository studentRepository;
	
	
	@Test
	public void saveTest()
	{
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		Mockito.when(studentRepository.save(Mockito.any())).thenReturn(student);
		Student finalResponse = studentServiceImpl.save(student);
		assertNotNull(finalResponse);
	}
	
	
	@Test
	public void getAllStudentsTest()
	{
		List<Student> studentList = new ArrayList<>();
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		studentList.add(student);
		Mockito.when(studentRepository.findAll()).thenReturn(studentList);
		assertNotNull(studentServiceImpl.getAllStudents());
	}


	@Test
	public void getAllStudentsGreaterThanNightyPercentageTest()
	{
		List<Student> studentList = new ArrayList<>();
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		student.setPercentage(90);
		studentList.add(student);
		Mockito.when(studentRepository.findAll()).thenReturn(studentList);
		assertNotNull(studentServiceImpl.getAllStudentsGreaterThanNightyPercentage());
	}

	@Test
	public void getStudentByIdTest() throws ResourceNotFoundException
	{
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		Optional<Student> student1 = Optional.ofNullable(student);
		Mockito.when(studentRepository.findById(Mockito.any())).thenReturn(student1);
		Student finalResponse = studentServiceImpl.getStudentById(1l);
		assertNotNull(finalResponse);
	}
	
	@Test
	public void getStudentByFirstAndLastNameTest() throws ResourceNotFoundException
	{
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		Mockito.when(studentRepository.findStudentByFirstAndLastName(Mockito.anyString(), Mockito.anyString())).thenReturn(student);
		Student finalResponse = studentServiceImpl.getStudentByFirstAndLastName("aaa","bbb");
		assertNotNull(finalResponse);
	}
	
	@Test
	public void deleteStudentTest()
	{
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		Mockito.doNothing().when(studentRepository).delete(student);
		studentServiceImpl.deleteStudent(student);
        Mockito.verify(studentRepository, times(1)).delete(student);
	}
	
	@Test
	public void updateStudentTest()
	{
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		student.setFatherName("aa");
		student.setMotherName("bb");
		student.setPercentage(90);
		student.setAddress("aa");
		Student student2 = new Student();
		student2.setFirstName("aaa");
		student2.setLastName("bbb");
		student2.setEmailId("abc@gmail.com");
		student2.setId(2);
		student2.setFatherName("aa");
		student2.setMotherName("bb");
		student2.setPercentage(90);
		student2.setAddress("aa");
		Mockito.when(studentRepository.save(Mockito.any())).thenReturn(student);
		assertNotNull(studentServiceImpl.updateStudent(student, student2));
	}
	

	@Test 
	public void findByFirstNameLastNameExp() throws ResourceNotFoundException
	{
		Mockito.when(studentRepository.findStudentByFirstAndLastName(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> {
			studentServiceImpl.getStudentByFirstAndLastName("aaa","bbb");
	    });
		
	}
}
