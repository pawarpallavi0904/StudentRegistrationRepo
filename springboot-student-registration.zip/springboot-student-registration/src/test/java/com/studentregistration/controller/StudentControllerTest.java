package com.studentregistration.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.studentregistration.exception.ResourceNotFoundException;
import com.studentregistration.model.Student;
import com.studentregistration.service.StudentService;

@SpringBootTest
public class StudentControllerTest 
{
	
	@Mock
	private StudentService studentService;
	
	@InjectMocks
	private StudentController studentController;
		
	
	@Test
	public void getAllstudentsTest()
	{
		List<Student> studentList = new ArrayList<>();
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		studentList.add(student);
		Mockito.when(studentService.getAllStudents()).thenReturn(studentList);
		assertNotNull(studentController.getAllstudents());		
	}
	
	@Test
	public void getAllStudentsGreaterThanNightyPercentageTest()
	{
		List<Student> studentList = new ArrayList<>();
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		studentList.add(student);
		Mockito.when(studentService.getAllStudentsGreaterThanNightyPercentage()).thenReturn(studentList);
		assertNotNull(studentController.getAllStudentsGreaterThanNightyPercentage());		
	}
	
	@Test
	public void getStudentByIdTest() throws ResourceNotFoundException
	{
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		Mockito.when(studentService.getStudentById(Mockito.any())).thenReturn(student);
		assertNotNull(studentController.getStudentById(1l));		
	}
	
	@Test
	public void getStudentByFirstAndLastNameTest() throws ResourceNotFoundException
	{
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		Mockito.when(studentService.getStudentByFirstAndLastName(Mockito.any(), Mockito.any())).thenReturn(student);
		assertNotNull(studentController.getStudentByFirstAndLastName("aa","aa"));		
	}
	
	@Test
	public void updateStudentTest() throws ResourceNotFoundException
	{
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		Mockito.when(studentService.getStudentById(Mockito.any())).thenReturn(student);
		Mockito.when(studentService.updateStudent(Mockito.any(),Mockito.any())).thenReturn(student);
		assertNotNull(studentController.updateStudent(1l,student));		
	}
	
	@Test
	public void deleteStudentTest() throws ResourceNotFoundException
	{
		Student student = new Student();
		student.setFirstName("aaa");
		student.setLastName("bbb");
		student.setEmailId("abc@gmail.com");
		student.setId(1);
		Mockito.when(studentService.getStudentById(Mockito.any())).thenReturn(student);
		assertNotNull(studentController.deleteStudent(1l));		
	}
}
